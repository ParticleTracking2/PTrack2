#!/bin/sh

autoconf --warnings=all --force
autoheader --warnings=all --force
