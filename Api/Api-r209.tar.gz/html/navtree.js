var NAVTREE =
[
  [ "PTrack 2 C++/CUDA", "index.html", [
    [ "PTrack2 C++/Cuda", "index.html", null ],
    [ "Lista de clases", "annotated.html", [
      [ "Algorithm", "class_algorithm.html", null ],
      [ "AlgorithmExecutor", "class_algorithm_executor.html", null ],
      [ "ArgObj", "struct_arg_obj.html", null ],
      [ "ArgsProcessor", "class_args_processor.html", null ],
      [ "BinaryOutput", "class_binary_output.html", null ],
      [ "Chi2Algorithm", "class_chi2_algorithm.html", null ],
      [ "Chi2HDAlgorithm", "class_chi2_h_d_algorithm.html", null ],
      [ "Chi2Lib", "class_chi2_lib.html", null ],
      [ "Chi2LibFFTW", "class_chi2_lib_f_f_t_w.html", null ],
      [ "Chi2LibFFTWCache", "class_chi2_lib_f_f_t_w_cache.html", null ],
      [ "Chi2LibHighDensity", "class_chi2_lib_high_density.html", null ],
      [ "Chi2LibMatrix", "class_chi2_lib_matrix.html", null ],
      [ "Chi2LibQhull", "class_chi2_lib_qhull.html", null ],
      [ "ConnectorOutput", "class_connector_output.html", null ],
      [ "Container", "class_container.html", null ],
      [ "FileUtils", "class_file_utils.html", null ],
      [ "ImageReader", "class_image_reader.html", null ],
      [ "JPGImageReader", "class_j_p_g_image_reader.html", null ],
      [ "KeyTreat", "struct_key_treat.html", null ],
      [ "MyImage", "class_my_image.html", null ],
      [ "MyImageFactory", "class_my_image_factory.html", null ],
      [ "MyLogger", "class_my_logger.html", null ],
      [ "MyMatrix< myType >", "class_my_matrix.html", null ],
      [ "MyPeak", "class_my_peak.html", null ],
      [ "Output", "class_output.html", null ],
      [ "OutputFactory", "class_output_factory.html", null ],
      [ "ParameterContainer", "class_parameter_container.html", null ],
      [ "PlainOutput", "class_plain_output.html", null ],
      [ "PNGImageReader", "class_p_n_g_image_reader.html", null ],
      [ "StandarOutput", "class_standar_output.html", null ],
      [ "TIFFImageReader", "class_t_i_f_f_image_reader.html", null ]
    ] ],
    [ "Índice de clases", "classes.html", null ],
    [ "Jerarquía de la clase", "hierarchy.html", [
      [ "Algorithm", "class_algorithm.html", [
        [ "Chi2Algorithm", "class_chi2_algorithm.html", null ],
        [ "Chi2HDAlgorithm", "class_chi2_h_d_algorithm.html", null ]
      ] ],
      [ "AlgorithmExecutor", "class_algorithm_executor.html", null ],
      [ "ArgObj", "struct_arg_obj.html", null ],
      [ "ArgsProcessor", "class_args_processor.html", null ],
      [ "Chi2Lib", "class_chi2_lib.html", null ],
      [ "Chi2LibFFTW", "class_chi2_lib_f_f_t_w.html", null ],
      [ "Chi2LibFFTWCache", "class_chi2_lib_f_f_t_w_cache.html", null ],
      [ "Chi2LibHighDensity", "class_chi2_lib_high_density.html", null ],
      [ "Chi2LibMatrix", "class_chi2_lib_matrix.html", null ],
      [ "Chi2LibQhull", "class_chi2_lib_qhull.html", null ],
      [ "Container", "class_container.html", null ],
      [ "FileUtils", "class_file_utils.html", null ],
      [ "ImageReader", "class_image_reader.html", [
        [ "JPGImageReader", "class_j_p_g_image_reader.html", null ],
        [ "PNGImageReader", "class_p_n_g_image_reader.html", null ],
        [ "TIFFImageReader", "class_t_i_f_f_image_reader.html", null ]
      ] ],
      [ "KeyTreat", "struct_key_treat.html", null ],
      [ "MyImage", "class_my_image.html", null ],
      [ "MyImageFactory", "class_my_image_factory.html", null ],
      [ "MyLogger", "class_my_logger.html", null ],
      [ "MyMatrix< myType >", "class_my_matrix.html", null ],
      [ "MyPeak", "class_my_peak.html", null ],
      [ "Output", "class_output.html", [
        [ "BinaryOutput", "class_binary_output.html", null ],
        [ "ConnectorOutput", "class_connector_output.html", null ],
        [ "PlainOutput", "class_plain_output.html", null ],
        [ "StandarOutput", "class_standar_output.html", null ]
      ] ],
      [ "OutputFactory", "class_output_factory.html", null ],
      [ "ParameterContainer", "class_parameter_container.html", null ]
    ] ],
    [ "Miembros de las clases", "functions.html", null ],
    [ "Lista de archivos", "files.html", [
      [ "src/Ptrack2.cpp", "_ptrack2_8cpp.html", null ],
      [ "src/Algorithm/Algorithm.cpp", "_algorithm_8cpp.html", null ],
      [ "src/Algorithm/Algorithm.h", "_algorithm_8h.html", null ],
      [ "src/Algorithm/AlgorithmExecutor.cpp", "_algorithm_executor_8cpp.html", null ],
      [ "src/Algorithm/AlgorithmExecutor.h", "_algorithm_executor_8h.html", null ],
      [ "src/Algorithm/AlgorithmTypes.h", "_algorithm_types_8h.html", null ],
      [ "src/Algorithm/MyPeak.cpp", "_my_peak_8cpp.html", null ],
      [ "src/Algorithm/MyPeak.h", "_my_peak_8h.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2Lib.cpp", "_chi2_lib_8cpp.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2Lib.h", "_chi2_lib_8h.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibFFTW.cpp", "_chi2_lib_f_f_t_w_8cpp.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibFFTW.h", "_chi2_lib_f_f_t_w_8h.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibFFTWCache.cpp", "_chi2_lib_f_f_t_w_cache_8cpp.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibFFTWCache.h", "_chi2_lib_f_f_t_w_cache_8h.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibHighDensity.cpp", "_chi2_lib_high_density_8cpp.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibHighDensity.h", "_chi2_lib_high_density_8h.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibMatrix.cpp", "_chi2_lib_matrix_8cpp.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibMatrix.h", "_chi2_lib_matrix_8h.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibQhull.cpp", "_chi2_lib_qhull_8cpp.html", null ],
      [ "src/Algorithm/Chi2Lib/Chi2LibQhull.h", "_chi2_lib_qhull_8h.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCuda.cpp", "_chi2_lib_cuda_8cpp.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCuda.h", "_chi2_lib_cuda_8h.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCudaFFT.cpp", "_chi2_lib_cuda_f_f_t_8cpp.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCudaFFT.h", "_chi2_lib_cuda_f_f_t_8h.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCudaFFTCache.cpp", "_chi2_lib_cuda_f_f_t_cache_8cpp.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCudaFFTCache.h", "_chi2_lib_cuda_f_f_t_cache_8h.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCudaHighDensity.cpp", "_chi2_lib_cuda_high_density_8cpp.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCudaHighDensity.h", "_chi2_lib_cuda_high_density_8h.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCudaQhull.cpp", "_chi2_lib_cuda_qhull_8cpp.html", null ],
      [ "src/Algorithm/Chi2LibCuda/Chi2LibCudaQhull.h", "_chi2_lib_cuda_qhull_8h.html", null ],
      [ "src/Algorithm/Implementations/Chi2Algorithm.cpp", "_chi2_algorithm_8cpp.html", null ],
      [ "src/Algorithm/Implementations/Chi2Algorithm.h", "_chi2_algorithm_8h.html", null ],
      [ "src/Algorithm/Implementations/Chi2HDAlgorithm.cpp", "_chi2_h_d_algorithm_8cpp.html", null ],
      [ "src/Algorithm/Implementations/Chi2HDAlgorithm.h", "_chi2_h_d_algorithm_8h.html", null ],
      [ "src/Algorithm/Implementations/Chi2HDCudaAlgorithm.cpp", "_chi2_h_d_cuda_algorithm_8cpp.html", null ],
      [ "src/Algorithm/Implementations/Chi2HDCudaAlgorithm.h", "_chi2_h_d_cuda_algorithm_8h.html", null ],
      [ "src/Arguments/ArgsProcessor.cpp", "_args_processor_8cpp.html", null ],
      [ "src/Arguments/ArgsProcessor.h", "_args_processor_8h.html", null ],
      [ "src/Arguments/Obj/KeyTreat.h", "_key_treat_8h.html", null ],
      [ "src/Container/Container.cpp", "_container_8cpp.html", null ],
      [ "src/Container/Container.h", "_container_8h.html", null ],
      [ "src/Container/MyMatrix.h", "_my_matrix_8h.html", null ],
      [ "src/Container/ParameterContainer.cpp", "_parameter_container_8cpp.html", null ],
      [ "src/Container/ParameterContainer.h", "_parameter_container_8h.html", null ],
      [ "src/Image/ImageReader.cpp", "_image_reader_8cpp.html", null ],
      [ "src/Image/ImageReader.h", "_image_reader_8h.html", null ],
      [ "src/Image/MyImage.cpp", "_my_image_8cpp.html", null ],
      [ "src/Image/MyImage.h", "_my_image_8h.html", null ],
      [ "src/Image/MyImageFactory.cpp", "_my_image_factory_8cpp.html", null ],
      [ "src/Image/MyImageFactory.h", "_my_image_factory_8h.html", null ],
      [ "src/Image/ImageReader/JPGImageReader.cpp", "_j_p_g_image_reader_8cpp.html", null ],
      [ "src/Image/ImageReader/JPGImageReader.h", "_j_p_g_image_reader_8h.html", null ],
      [ "src/Image/ImageReader/PNGImageReader.cpp", "_p_n_g_image_reader_8cpp.html", null ],
      [ "src/Image/ImageReader/PNGImageReader.h", "_p_n_g_image_reader_8h.html", null ],
      [ "src/Image/ImageReader/TIFFImageReader.cpp", "_t_i_f_f_image_reader_8cpp.html", null ],
      [ "src/Image/ImageReader/TIFFImageReader.h", "_t_i_f_f_image_reader_8h.html", null ],
      [ "src/Output/Output.cpp", "_output_8cpp.html", null ],
      [ "src/Output/Output.h", "_output_8h.html", null ],
      [ "src/Output/OutputFactory.cpp", "_output_factory_8cpp.html", null ],
      [ "src/Output/OutputFactory.h", "_output_factory_8h.html", null ],
      [ "src/Output/OutImpl/BinaryOutput.cpp", "_binary_output_8cpp.html", null ],
      [ "src/Output/OutImpl/BinaryOutput.h", "_binary_output_8h.html", null ],
      [ "src/Output/OutImpl/ConnectorOutput.cpp", "_connector_output_8cpp.html", null ],
      [ "src/Output/OutImpl/ConnectorOutput.h", "_connector_output_8h.html", null ],
      [ "src/Output/OutImpl/PlainOutput.cpp", "_plain_output_8cpp.html", null ],
      [ "src/Output/OutImpl/PlainOutput.h", "_plain_output_8h.html", null ],
      [ "src/Output/OutImpl/StandarOutput.cpp", "_standar_output_8cpp.html", null ],
      [ "src/Output/OutImpl/StandarOutput.h", "_standar_output_8h.html", null ],
      [ "src/Utils/FileUtils.cpp", "_file_utils_8cpp.html", null ],
      [ "src/Utils/FileUtils.h", "_file_utils_8h.html", null ],
      [ "src/Utils/MyLogger.cpp", "_my_logger_8cpp.html", null ],
      [ "src/Utils/MyLogger.h", "_my_logger_8h.html", null ]
    ] ],
    [ "Directorios", "dirs.html", [
      [ "src", "dir_6843526ecfe91d74c51ab8083199d582.html", [
        [ "Algorithm", "dir_39de92efa378cb35af6ae8b91ad9b8a9.html", [
          [ "Chi2Lib", "dir_6fd8b478e99276d2f896baa45cb8d73f.html", null ],
          [ "Chi2LibCuda", "dir_66d0338dc54918d6eb3c43e5497aace0.html", null ],
          [ "Implementations", "dir_9c30e6cabb1d2997a0a138bb094588d0.html", null ]
        ] ],
        [ "Arguments", "dir_a10c7b3ba7219e48c2e236cf5f6f7958.html", [
          [ "Obj", "dir_314ea7f04e25f68ee9bb2348272e240c.html", null ]
        ] ],
        [ "Container", "dir_d1b12e5c6bc18c6a97fcda67fc602072.html", null ],
        [ "Image", "dir_b4c1c2af3a66ff1a3b68ecccdd834430.html", [
          [ "ImageReader", "dir_7d14d30b4278fe8cff926811235d38fa.html", null ]
        ] ],
        [ "Output", "dir_d34c732631ac74d50e252324a968cf8f.html", [
          [ "OutImpl", "dir_6865729aeef2532c24c8ac0ea2811025.html", null ]
        ] ],
        [ "Utils", "dir_0c0f8f9cf651c2fd75a15599b4738d07.html", null ]
      ] ]
    ] ],
    [ "Miembros de los ficheros", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

